#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
with_example=false
case "$#:${1-}" in
  0:) ;;
  1:--qualified-example) with_example=true ;;
  *) printf 'Usage: %s [--qualified-example]\n' "$0" >&2; exit 2 ;;
esac

compiler="$(rustup which --toolchain 1.93.1 rustc)"
toolchain="$(dirname -- "$(dirname -- "$compiler")")"
printf '%s  %s\n' bd1875234c27f9f0c9f9c700ade69f7e83d25e368f38407d32b4b0e2cbc2426d "$compiler" | sha256sum --check --status

scratch="$(mktemp -d .sdk-build.XXXXXXXX)"
cleanup() {
  local file
  for file in host.rs rule.rs libeden_gateway_remediation.rlib method.so; do
    if [[ -f "$scratch/$file" ]]; then
      unlink "$scratch/$file"
    fi
  done
  rmdir "$scratch/sdk" "$scratch"
}
mkdir "$scratch/sdk"
trap cleanup EXIT

if "$with_example"; then
  cp examples/qualified-method-path/{host.rs,rule.rs} "$scratch/"
fi

# Rust metadata records absolute source paths. Recreate the qualified /work
# layout and run the pinned compiler in a network-isolated mount namespace.
bwrap --unshare-all --die-with-parent --new-session \
  --ro-bind /usr /usr --ro-bind-try /lib /lib --ro-bind-try /lib64 /lib64 \
  --ro-bind-try /etc/alternatives /etc/alternatives \
  --ro-bind "$toolchain" /tools/rust --bind "$scratch" /work --chdir /work \
  --ro-bind "$(pwd -P)/sdk" /work/sdk \
  --dev /dev --proc /proc --tmpfs /tmp \
  /usr/bin/bash -eu -c '
    /tools/rust/bin/rustc --edition=2024 --crate-type=rlib --crate-name=eden_gateway_remediation \
      -C opt-level=3 -C panic=abort -C embed-bitcode=yes \
      sdk/lib.rs -o libeden_gateway_remediation.rlib
    if "$1"; then
      /tools/rust/bin/rustc --edition=2024 --crate-type=cdylib --crate-name=eden_method_shape \
        -C opt-level=3 -C panic=abort -C lto=fat -C codegen-units=1 \
        -C link-arg=-nostartfiles -C force-unwind-tables=no \
        --extern eden_gateway_remediation=libeden_gateway_remediation.rlib \
        host.rs -o method.so
    fi
  ' -- "$with_example"

(
  cd "$scratch"
  printf '%s  %s\n' c04c5d6e863d56befd246a596456cf1705af1bcaca6ecba82839072bc6d8bc2b libeden_gateway_remediation.rlib | sha256sum --check
  if "$with_example"; then
    printf '%s  %s\n' 876a04ebde2cfb87a8831b62d850dbde9baa77b0d6cb5790bdea70f605f9b248 method.so | sha256sum --check
  fi
)
mv -T "$scratch/libeden_gateway_remediation.rlib" libeden_gateway_remediation.rlib
if "$with_example"; then
  mv -T "$scratch/method.so" method.so
fi
