# Rebuild the qualified method-and-path example

This exact, bounded example admits two synthetic requests to `proof.example`.
Its rule and V1 wrapper correspond to the documented
`Http1MethodPathV1` Sphinx policy. Use a GNU C linker, Rust 1.93.1, and
Bubblewrap on a Linux x86-64 GNU machine with user namespaces.

From the root of the SDK release, run:

```sh
./build-pinned-sdk.sh --qualified-example
```

The script rebuilds the pinned SDK and checks the SHA-256 of the resulting
`method.so` against the exact ELF qualified for ordinary Sphinx admission.
Installation still uses the signed native proof and authority for the exact
policy, module and deployment.
