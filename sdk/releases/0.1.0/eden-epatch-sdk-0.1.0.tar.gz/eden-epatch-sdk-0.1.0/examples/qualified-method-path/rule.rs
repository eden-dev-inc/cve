//! Source candidate for the host's V1 method and path policy.
//!
//! The qualified wrapper must supply the complete, owner-local frame. This
//! rule uses only bounded byte comparisons and returns a scalar decision.

/// Allows the two exact canonical frames authorized by the V1 policy.
///
/// The input must be the owned frame's available bytes. The caller checks
/// completion before evaluating. A false result grants no upstream release.
pub fn allows(frame: &[u8]) -> bool {
    matches!(
        frame,
        b"GET /status HTTP/1.1\r\nHost: proof.example\r\n\r\n" | b"HEAD /health HTTP/1.1\r\nHost: proof.example\r\n\r\n"
    )
}
