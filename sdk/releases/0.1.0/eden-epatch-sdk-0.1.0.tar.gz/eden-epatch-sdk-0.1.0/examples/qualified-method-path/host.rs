//! Host-owned proof-carrying HTTP V1 adapter for a certified method rule.
#![no_std]

use core::panic::PanicInfo;
use eden_gateway_remediation::message::MessageInput;
use eden_gateway_remediation::module::{self, ApiHeader, Decision, EditSink, Edits, Failure, ModuleOutput, RemediationModule};
use eden_gateway_remediation::native_http_v3::{self as http, Api, Input, Request};

/// The producer copies only a completely parsed source rule to this path.
#[path = "rule.rs"]
mod rule;

/// This path must be unreachable from both entries in the linked image.
#[panic_handler]
fn panic(_: &PanicInfo<'_>) -> ! {
    loop {
        core::hint::spin_loop();
    }
}

/// Stateless adapter for a pure byte-pattern rule.
struct Rule;

impl<'a> RemediationModule<Request<'a>> for Rule {
    fn evaluate(&self, request: &Request<'a>, _: &mut Edits<'_>) -> Result<Decision, Failure> {
        let message = request.message();
        if !message.is_complete() {
            return Ok(Decision::NeedMore);
        }
        if rule::allows(message.prefix()) {
            Ok(Decision::Continue)
        } else {
            Ok(Decision::Refuse)
        }
    }
}

/// Forward the host's current borrowed layout to the proof-carrying HTTP V1 SDK.
unsafe extern "C" fn evaluate(input: *const Input, sink: *const EditSink, output: *mut ModuleOutput) -> i32 {
    // SAFETY: the host retains the ABI input and its exclusive state, current
    // sink and writable output until this call returns. The SDK confines
    // access to this borrow, and the source rule can only return a Boolean.
    unsafe { http::invoke(&Rule, input, sink, output) }
}

/// Image-owned proof-carrying HTTP V1 descriptor for a stateless rule with no helper requirements.
static API: Api = Api {
    header: ApiHeader { version: http::VERSION, table_size: core::mem::size_of::<Api>() as u32 },
    input_size: core::mem::size_of::<Input>() as u32,
    output_size: core::mem::size_of::<ModuleOutput>() as u32,
    sink_size: core::mem::size_of::<EditSink>() as u32,
    message_size: core::mem::size_of::<MessageInput>() as u32,
    state_bytes: 0,
    capabilities: module::CONTINUE | module::REFUSE | module::NEED_MORE,
    required_inputs: 0,
    evaluate: Some(evaluate),
};

/// Return the sole proof-carrying HTTP V1 ABI descriptor from the loaded image.
#[unsafe(no_mangle)]
pub extern "C" fn eden_http_proof_remediation_v1() -> *const Api {
    &API
}
