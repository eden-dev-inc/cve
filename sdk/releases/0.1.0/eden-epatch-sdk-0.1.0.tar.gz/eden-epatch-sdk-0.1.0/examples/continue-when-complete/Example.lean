/-! Source-level model of the example's decision on the host completeness flag. -/

namespace ContinueWhenCompleteExample

/-- The two decisions proposed by the example. -/
inductive Decision where
  | continueRequest
  | needMore

/-- The policy uses the SDK's original-message completeness flag. -/
def evaluate (complete : Bool) : Decision :=
  if complete then .continueRequest else .needMore

/-- Every incomplete request remains pending. -/
theorem incomplete_waits : evaluate false = .needMore := rfl

/-- A complete request receives a continuation proposal. -/
theorem complete_continues : evaluate true = .continueRequest := rfl

end ContinueWhenCompleteExample
