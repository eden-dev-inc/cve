//! Minimal native HTTP Proof V1 module for synthetic requests.
//!
//! ## Overview
//! The module waits for the host to report a complete request, then returns
//! `Continue` with zero edits.
//!
//! ## Architecture
//! The SDK adapts the synchronous Rust implementation to the C ABI. The host
//! owns the input, edit sink and output, while the module owns a static table.
//!
//! ## Core concepts
//! The SDK's completeness flag describes the entire original message. A
//! complete head alone leaves the request pending.
//!
//! ## Usage
//! Build the shared library with the offline command in the example README.
//!
//! ## Error handling
//! The SDK adapter returns nonzero for invalid ABI descriptors it can check.

#![no_std]

use core::panic::PanicInfo;

use eden_gateway_remediation::message::MessageInput;
use eden_gateway_remediation::module::{self, ApiHeader, Decision, EditSink, Edits, Failure, ModuleOutput, RemediationModule};
use eden_gateway_remediation::native_http_v3::{self, Api, Input, Request};

/// Waits for a complete HTTP request and proposes continuation with zero edits.
struct ContinueWhenComplete;

impl RemediationModule<Request<'_>> for ContinueWhenComplete {
    fn evaluate(&self, request: &Request<'_>, _edits: &mut Edits<'_>) -> Result<Decision, Failure> {
        if request.message().is_complete() {
            Ok(Decision::Continue)
        } else {
            Ok(Decision::NeedMore)
        }
    }
}

/// Supplies the required panic handler for the no-std example.
#[panic_handler]
fn panic(_: &PanicInfo<'_>) -> ! {
    loop {
        core::hint::spin_loop();
    }
}

/// Adapts one synchronous host call to the SDK's borrowed request and edit views.
///
/// # Safety
///
/// The host must supply aligned, live input, sink and output for this invocation
/// and uphold the callback, original byte and exclusive state contracts of
/// [`native_http_v3::invoke`].
unsafe extern "C" fn evaluate(input: *const Input, sink: *const EditSink, output: *mut ModuleOutput) -> i32 {
    // SAFETY: the host supplies the live buffers and callbacks required by the SDK.
    unsafe { native_http_v3::invoke(&ContinueWhenComplete, input, sink, output) }
}

/// Advertises the example's two decisions, zero state and zero input helpers.
static API: Api = Api {
    header: ApiHeader {
        version: native_http_v3::VERSION,
        table_size: core::mem::size_of::<Api>() as u32,
    },
    input_size: core::mem::size_of::<Input>() as u32,
    output_size: core::mem::size_of::<ModuleOutput>() as u32,
    sink_size: core::mem::size_of::<EditSink>() as u32,
    message_size: core::mem::size_of::<MessageInput>() as u32,
    state_bytes: 0,
    capabilities: module::CONTINUE | module::NEED_MORE,
    required_inputs: 0,
    evaluate: Some(evaluate),
};

/// Returns the example's immutable native HTTP Proof V1 table.
// SAFETY: this is the single entry point for the versioned SDK ABI.
#[unsafe(no_mangle)]
pub extern "C" fn eden_http_proof_remediation_v1() -> *const Api {
    &API
}
