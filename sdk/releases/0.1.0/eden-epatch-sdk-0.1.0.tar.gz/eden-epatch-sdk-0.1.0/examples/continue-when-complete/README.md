# Continue when complete

This example uses the SDK's qualified HTTP request view to return `NeedMore`
while the original request is incomplete and `Continue` once it is complete.
It uses the host's completeness flag and submits zero edits. The policy is an
authoring example for synthetic requests.

From the root of the standalone SDK, build with Rust 1.93.1 on Linux x86-64 GNU
and a system C linker.

```sh
cargo +1.93.1 rustc --offline --release --target x86_64-unknown-linux-gnu \
  --manifest-path examples/continue-when-complete/Cargo.toml \
  -- -C link-arg=-nostartfiles -C force-unwind-tables=no
```

With Cargo's default target directory, the build produces
`examples/continue-when-complete/target/x86_64-unknown-linux-gnu/release/libeden_sdk_continue_example.so`.
The library exposes `eden_http_proof_remediation_v1`.

Use Lean 4.36.0-rc2 to check the two branches of the Boolean policy model.

```sh
lean examples/continue-when-complete/Example.lean
```

The Lean model covers the decision for each value of the completeness flag.
Production Proof V1 admission requires a verifier-qualified source, witness and
exact image, plus separate signing and host authorization.
