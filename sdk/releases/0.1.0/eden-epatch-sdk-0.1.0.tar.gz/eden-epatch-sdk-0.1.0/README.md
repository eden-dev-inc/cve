# Eden Patch SDK

Author Rust patches for Sphinx's native HTTP Proof V1 ABI on Linux x86-64 GNU. The SDK is licensed under Apache-2.0.

## Build

From the unpacked release, use Rust 1.93.1 and run `cargo check --offline` to check the authoring crate. The [authoring example](examples/continue-when-complete/README.md) builds a module and checks its Lean policy model.

To reproduce the first qualified SDK library byte for byte, install Bubblewrap and run `./build-pinned-sdk.sh` on Linux x86-64 GNU with user namespaces enabled. The script checks the compiler digest, recreates the qualified build path, and checks the result against the expected SHA-256.

The [qualified method-and-path example](examples/qualified-method-path/README.md) uses the same SDK to reproduce a benign module already qualified for ordinary Sphinx admission.

Use the library as the `eden_gateway_remediation` dependency. The supported interface is profile `native-http-proof-v1` with numeric ABI version `1` and export `eden_http_proof_remediation_v1`. In this source release the V1 definitions are in the `native_http_v3` Rust module. The Rust module name is historical. The Registry and Sphinx use the profile, export and numeric version above.

The release manifest records the source revision, compiler version and file digests. Keep the SDK release and compiler pinned when reproducing a patch build. Sphinx admission binds the exact compiled patch to its proof and signed authority. The Registry separately verifies signed release evidence and the publisher.
