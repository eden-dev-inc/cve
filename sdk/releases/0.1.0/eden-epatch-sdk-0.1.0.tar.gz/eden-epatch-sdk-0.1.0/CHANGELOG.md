# Eden Patch SDK changelog

## 0.1.0

- Publish the Rust authoring source for the native HTTP Proof V1 ABI on Linux x86-64 GNU.
- Include the exact standalone library build recipe and a release manifest containing checksums.
