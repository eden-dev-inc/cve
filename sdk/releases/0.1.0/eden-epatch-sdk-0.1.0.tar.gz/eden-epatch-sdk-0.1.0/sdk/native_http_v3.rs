//! Proof-carrying HTTP V1 adapter over the shared borrowed message capabilities.
//!
//! The protocol host supplies original ranges and explicit head completeness.
//! The generic module trait owns condition logic. This ABI permits an explicit
//! NeedMore decision while the host retains an incomplete request.
//! When independently granted, edits use offsets in the complete original HTTP
//! message, including its head. The host refuses edits before completeness and
//! validates corrected framing/output bounds before allowing upstream effects.

/// Scalar descriptor admission shared by incremental HTTP hosts.
#[path = "native_http_v3/validation.rs"]
pub mod validation;

use crate::message::{Availability, ByteRange, MAX_STATE_BYTES, Message, MessageInput};
use crate::module::{ApiHeader, EditSink, Failure, ModuleOutput, RemediationModule};

/// Numeric version of the proof-carrying HTTP C table.
pub const VERSION: u32 = 1;
/// Every known decision bit for this version; host grants still prevail.
pub const CAPABILITIES: u64 = crate::module::CAPABILITIES | crate::module::NEED_MORE;
/// NUL-terminated export that returns the proof-carrying HTTP V1 ABI table.
pub const ABI_SYMBOL: &core::ffi::CStr = c"eden_http_proof_remediation_v1";
/// Export name recorded in artifact declarations and proof commitments.
pub const ABI_EXPORT: &str = match core::str::from_utf8(ABI_SYMBOL.to_bytes()) {
    Ok(name) => name,
    Err(_) => panic!("the proof-carrying HTTP export must be UTF-8"),
};
/// Package protocol identity for the proof-carrying HTTP V1 ABI.
pub const PROFILE: &str = "native-http-proof-v1";

/// Two original ranges for one duplicate-preserving header.
#[repr(C)]
pub struct HeaderRanges {
    /// Original header name bytes, preserving case.
    pub name: ByteRange,
    /// Original parser-qualified header value bytes.
    pub value: ByteRange,
}

/// Original name and value views, both expiring with their native invocation.
pub type Header<'a> = (&'a [u8], &'a [u8]);

/// Incremental HTTP input; all addresses are borrowed for one invocation.
#[repr(C)]
pub struct Input {
    /// Shared original-byte, request-state and bounded helper contract.
    pub message: MessageInput,
    /// One only after canonical framing validates the entire request head.
    pub head_complete: u32,
    /// Original method token; inaccessible until the head is complete.
    pub method: ByteRange,
    /// Original request target, including its query.
    pub target: ByteRange,
    /// Declared original body range, including bytes not yet received.
    pub body: ByteRange,
    /// Number of original headers after the head is complete.
    pub header_count: u32,
    /// Read a scalar header range pair without constructing header strings.
    pub header_at: unsafe extern "C" fn(*mut core::ffi::c_void, u32, *mut HeaderRanges) -> u32,
}

/// Qualified HTTP view with request-local state and shared helper capabilities.
pub struct Request<'a> {
    /// Protocol metadata for this synchronous invocation only.
    input: &'a Input,
    /// Safe shared access; exclusive state/scratch never escapes its callbacks.
    message: Message<'a>,
}

impl<'a> Request<'a> {
    /// Shared protocol-independent original-byte, state and decode access.
    pub fn message(&self) -> &Message<'a> {
        &self.message
    }

    /// Read the original validated method, or explicitly await the head.
    pub fn method(&self) -> Result<Availability<&'a [u8]>, Failure> {
        if self.input.head_complete == 0 {
            return Ok(Availability::NeedMore);
        }
        self.message.bytes(self.input.method)
    }

    /// Read the original validated request target, including its query.
    pub fn target(&self) -> Result<Availability<&'a [u8]>, Failure> {
        if self.input.head_complete == 0 {
            return Ok(Availability::NeedMore);
        }
        self.message.bytes(self.input.target)
    }

    /// Obtain the declared original body range without claiming it has arrived.
    pub fn body_range(&self) -> Availability<ByteRange> {
        if self.input.head_complete == 0 {
            Availability::NeedMore
        } else {
            Availability::Ready(self.input.body)
        }
    }

    /// Obtain duplicate-preserving header count only after head completion.
    pub fn header_count(&self) -> Availability<u32> {
        if self.input.head_complete == 0 {
            Availability::NeedMore
        } else {
            Availability::Ready(self.input.header_count)
        }
    }

    /// Borrow one original header; absence and an incomplete head are distinct.
    pub fn header(&self, index: u32) -> Result<Availability<Option<Header<'a>>>, Failure> {
        if self.input.head_complete == 0 {
            return Ok(Availability::NeedMore);
        }
        if index >= self.input.header_count {
            return Ok(Availability::Ready(None));
        }
        let mut ranges = core::mem::MaybeUninit::<HeaderRanges>::uninit();
        // SAFETY: the host retains its original header index for this call.
        if unsafe { (self.input.header_at)(self.input.message.context, index, ranges.as_mut_ptr()) } != crate::message::READY {
            return Err(Failure);
        }
        // SAFETY: READY initializes both scalar ranges.
        let ranges = unsafe { ranges.assume_init() };
        match (self.message.bytes(ranges.name)?, self.message.bytes(ranges.value)?) {
            (Availability::Ready(name), Availability::Ready(value)) => Ok(Availability::Ready(Some((name, value)))),
            _ => Err(Failure),
        }
    }
}

/// Exact versioned C layout; no allocator-owned object crosses this boundary.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct Api {
    /// Version and exact complete table size.
    pub header: ApiHeader,
    /// Exact expected [`Input`] size.
    pub input_size: u32,
    /// Exact expected [`ModuleOutput`] size.
    pub output_size: u32,
    /// Exact expected [`EditSink`] size.
    pub sink_size: u32,
    /// Expected shared [`MessageInput`] layout size.
    pub message_size: u32,
    /// Required per-request state bytes, at most [`MAX_STATE_BYTES`].
    pub state_bytes: u32,
    /// Declared decision bits, independently limited by the host.
    pub capabilities: u64,
    /// Required shared input helper bits; unavailable requirements refuse early.
    pub required_inputs: u64,
    /// Synchronous evaluation; zero initializes a scalar decision.
    pub evaluate: Option<unsafe extern "C" fn(*const Input, *const EditSink, *mut ModuleOutput) -> i32>,
}

/// Invoke the generic authoring trait on one incremental borrowed HTTP view.
///
/// # Safety
/// Input/sink/output must be aligned and live for this synchronous call. The
/// host retains original bytes, callbacks, exclusive state and scratch, and must
/// not mutate prefix bytes during evaluation. No callback or borrowed value may
/// escape. The common invocation contains Rust unwinding with `std`; native
/// aborts, faults and nonreturning calls retain their existing trust limitations.
pub unsafe fn invoke<M>(module: &M, input: *const Input, sink: *const EditSink, output: *mut ModuleOutput) -> i32
where
    for<'a> M: RemediationModule<Request<'a>>,
{
    if input.is_null() || output.is_null() {
        return 1;
    }
    // SAFETY: the host supplies aligned writable output and input storage.
    unsafe { output.write(ModuleOutput { decision: u32::MAX }) };
    // SAFETY: input is a live trusted host layout for this call.
    let input = unsafe { &*input };
    if input.head_complete > 1
        || input.message.complete > 1
        || input.message.state.len > MAX_STATE_BYTES
        || input.message.state.data.is_null()
    {
        return 1;
    }
    // SAFETY: this adapter forwards the caller's exclusive state/view contract.
    let message = unsafe { Message::new(&input.message) };
    let request = Request { input, message };
    // SAFETY: the generic invocation uses only this call's live sink/output.
    unsafe { crate::module::invoke(module, &request, sink, output) }
}
