//! Pure original-range validation shared by incremental message adapters.
//!
//! The result describes offsets into an arrived prefix without borrowing or
//! dereferencing module-owned bytes.

use super::ByteRange;
use crate::module::Failure;

/// Arrived portion of a valid original range, containing no borrowed pointer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RangeWindow {
    /// Inclusive original offset, no greater than the arrived prefix length.
    pub start: usize,
    /// Exclusive arrived offset, between start and the prefix length.
    pub end: usize,
    /// Whether every byte of the requested original range has arrived.
    pub complete: bool,
}

/// Refuse invalid offsets, or describe exactly their arrived intersection.
/// `None` means the valid range starts beyond the current prefix.
#[inline]
pub fn arrival_window(range: ByteRange, extent: u32, arrived: usize) -> Result<Option<RangeWindow>, Failure> {
    if range.start > range.end || range.end > extent {
        return Err(Failure);
    }
    if range.start as usize > arrived {
        return Ok(None);
    }
    Ok(Some(RangeWindow {
        start: range.start as usize,
        end: (range.end as usize).min(arrived),
        complete: range.end as usize <= arrived,
    }))
}
