//! Protocol-independent native-module authoring and decision contracts.
//!
//! Gateways supply a qualified borrowed input view to [`RemediationModule`].
//! All adapters share capabilities, scalar outcomes, bounded edit submission,
//! failure handling and host ownership. Rust trait objects stay within a binary;
//! each protocol's C table adapts these traits without worker transport.

// Preserve the same child source when this module is imported by extraction.
#[path = "module/validation.rs"]
pub mod validation;

use core::marker::PhantomData;
#[cfg(feature = "std")]
use std::panic::{AssertUnwindSafe, catch_unwind};

/// Borrowed bytes, valid only during the current module invocation.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct BorrowedBytes {
    /// Readable byte address, including a non-null dangling address when empty.
    pub data: *const u8,
    /// Number of readable bytes.
    pub len: usize,
}

impl BorrowedBytes {
    /// Form an ABI view without copying the source allocation.
    pub fn new(value: &[u8]) -> Self {
        Self { data: value.as_ptr(), len: value.len() }
    }

    /// Borrow the view for no longer than its original host input.
    ///
    /// # Safety
    /// The caller must ensure the pointer and length describe live readable
    /// bytes for `'a`, and must not mutate or retain this storage.
    pub unsafe fn as_slice<'a>(&self) -> &'a [u8] {
        // SAFETY: the module caller guarantees the documented lifetime/layout.
        unsafe { core::slice::from_raw_parts(self.data, self.len) }
    }
}

/// Readable prefix used before the host reads the complete table.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct ApiHeader {
    /// Exact supported protocol ABI version.
    pub version: u32,
    /// Exact byte size of the protocol's complete C function table.
    pub table_size: u32,
}

/// Module may continue an inspected request without changing it.
pub const CONTINUE: u64 = 1;
/// Module may refuse using its protocol adapter's host-admitted response.
pub const REFUSE: u64 = 2;
/// Module may submit bounded qualified-payload replacements to the host.
pub const EDIT: u64 = 4;
/// Module may retain the request gate while awaiting more original input.
/// Only an incremental ABI grants this bit; older tables retain their mask.
pub const NEED_MORE: u64 = 8;
/// All capabilities understood by this ABI version.
pub const CAPABILITIES: u64 = CONTINUE | REFUSE | EDIT;
/// Maximum non-overlapping edits proposed by one call.
pub const MAX_EDITS: usize = 32;
/// Maximum total replacement bytes copied by one call.
pub const MAX_REPLACEMENT_BYTES: usize = 64 * 1024;

/// Scalar decision shared by all native protocol tables.
#[repr(C)]
pub struct ModuleOutput {
    /// Zero continues, one refuses, two proposes edits, three awaits input.
    /// Other values fail; older ABI grants exclude the incremental decision.
    /// The host also checks that the selected ABI permits this capability.
    pub decision: u32,
}

/// Authoring decision, converted to a scalar before crossing the C boundary.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Decision {
    /// Continue with no submitted edits.
    Continue,
    /// Refuse before upstream effects, with no submitted edits.
    Refuse,
    /// Return the successfully submitted edits for host validation.
    Edit,
    /// Keep the request pending without proposing edits or upstream effects.
    NeedMore,
}

/// Bounded failure; no module error string or payload crosses the ABI.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Failure;

/// Host-owned collection callback. The host copies replacement bytes before
/// returning; it must retain no module pointer or module-owned allocation.
#[repr(C)]
pub struct EditSink {
    /// Opaque host call context; modules must not inspect or retain it.
    pub context: *mut core::ffi::c_void,
    /// Submit a half-open body span. Zero accepts; any other value fails.
    pub replace: unsafe extern "C" fn(*mut core::ffi::c_void, u32, u32, BorrowedBytes) -> i32,
}

/// Safe, call-scoped edit builder supplied to the module author.
pub struct Edits<'a> {
    /// Host callback and context for this invocation only.
    sink: &'a EditSink,
    /// Prevent the builder from escaping its borrowed invocation.
    lifetime: PhantomData<&'a mut ()>,
}

impl<'a> Edits<'a> {
    /// Construct a call-scoped builder inside a qualified binary adapter.
    pub(crate) fn from_sink(sink: &'a EditSink) -> Self {
        Self { sink, lifetime: PhantomData }
    }

    /// Propose replacement of `[start, end)` in the original qualified payload. Empty bytes
    /// delete the span. Submit spans in order; host bounds and grants prevail.
    pub fn replace(&mut self, start: u32, end: u32, replacement: &[u8]) -> Result<(), Failure> {
        // SAFETY: invoke's caller supplies the current host sink. The host only
        // borrows these replacement bytes until this callback returns.
        match unsafe { (self.sink.replace)(self.sink.context, start, end, BorrowedBytes::new(replacement)) } {
            0 => Ok(()),
            _ => Err(Failure),
        }
    }
}

/// Rust modules implement condition logic locally; the gateway owns effects.
/// Implementations must be synchronous and thread-safe and retain no input,
/// sink, callback or request pointer. Native host approval covers dependencies.
pub trait RemediationModule<I: ?Sized>: Sync {
    /// Inspect the adapter-qualified input and propose an outcome before effects.
    /// Incremental adapters distinguish NeedMore from conclusive continuation.
    fn evaluate(&self, request: &I, edits: &mut Edits<'_>) -> Result<Decision, Failure>;
}

/// Host-owned proposed protocol-payload replacement; no pointer into module code or data.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg(feature = "std")]
pub struct ByteEdit {
    /// Inclusive offset in the original qualified protocol payload, in bytes.
    pub start: u32,
    /// Exclusive offset in the original qualified protocol payload, in bytes.
    pub end: u32,
    /// Bounded copied replacement; empty means deletion.
    pub replacement: Vec<u8>,
}

/// Invoke shared module logic, containing Rust unwinding when `std` is enabled.
/// Every protocol adapter delegates to this same authoring/error boundary.
/// Returns nonzero on failure and leaves an invalid scalar on that path.
///
/// # Safety
/// The sink must fulfill its live callback contract; output must be aligned and
/// writable. The adapter must retain input storage throughout this call. Compile
/// with `panic=unwind` for the `std` panic boundary. Without `std`, the module
/// supplies its own panic handler and must fulfill the host-approved non-panicking
/// call contract. Aborts, stuck handlers and native memory faults are not contained.
pub unsafe fn invoke<M, I: ?Sized>(module: &M, input: &I, sink: *const EditSink, output: *mut ModuleOutput) -> i32
where
    M: RemediationModule<I>,
{
    if sink.is_null() || output.is_null() {
        return 1;
    }
    // SAFETY: caller guarantees aligned writable output storage.
    unsafe { output.write(ModuleOutput { decision: u32::MAX }) };
    let evaluate = || {
        // SAFETY: the protocol adapter guarantees this live call-scoped sink.
        let mut edits = Edits::from_sink(unsafe { &*sink });
        module.evaluate(input, &mut edits)
    };
    #[cfg(feature = "std")]
    let result = match catch_unwind(AssertUnwindSafe(evaluate)) {
        Ok(result) => result,
        Err(_) => return 1,
    };
    #[cfg(not(feature = "std"))]
    let result = evaluate();
    let Ok(decision) = result else { return 1 };
    let decision = match decision {
        Decision::Continue => 0,
        Decision::Refuse => 1,
        Decision::Edit => 2,
        Decision::NeedMore => 3,
    };
    // SAFETY: caller guarantees aligned writable output storage.
    unsafe { output.write(ModuleOutput { decision }) };
    0
}
