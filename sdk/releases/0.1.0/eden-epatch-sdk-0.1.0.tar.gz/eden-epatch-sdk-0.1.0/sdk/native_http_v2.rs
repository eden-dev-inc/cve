//! HTTP binary adapter for the shared native [`RemediationModule`] contract.
//!
//! The adapter borrows canonical HTTP parser views. Its default `std` mode
//! contains Rust unwinding within the module binary; `no_std` authors supply
//! their own panic handler. Capabilities, edits and outcomes are shared across
//! gateways. No trait object or owned Rust value crosses the C table.

#[cfg(feature = "std")]
pub use super::module::ByteEdit;
pub use super::module::{
    CAPABILITIES, CONTINUE, Decision, EDIT, EditSink, Edits, Failure, MAX_EDITS, MAX_REPLACEMENT_BYTES, REFUSE, RemediationModule,
};
use super::native_http::{Header, HeaderVersion, Input, Output};

/// HTTP native edit ABI, exported through `eden_http_remediation_v2`.
pub const VERSION: u32 = 2;

/// A complete HTTP request borrowed only for the synchronous native call.
pub struct Request<'a> {
    /// Host parser storage, never retained beyond the call.
    input: &'a Input,
}

impl<'a> Request<'a> {
    /// Original validated HTTP method bytes.
    pub fn method(&self) -> &'a [u8] {
        // SAFETY: invoke's caller guarantees every input view for this call.
        unsafe { self.input.method.as_slice() }
    }

    /// Original validated target, including its query string.
    pub fn target(&self) -> &'a [u8] {
        // SAFETY: invoke's caller guarantees every input view for this call.
        unsafe { self.input.target.as_slice() }
    }

    /// Complete bounded body, without cloning or serialization.
    pub fn body(&self) -> &'a [u8] {
        // SAFETY: invoke's caller guarantees every input view for this call.
        unsafe { self.input.body.as_slice() }
    }

    /// Number of original headers, including duplicates.
    pub fn header_count(&self) -> usize {
        self.input.header_count
    }

    /// Borrow one duplicate-preserving header; an unavailable index fails.
    pub fn header(&self, index: usize) -> Result<(&'a [u8], &'a [u8]), Failure> {
        if index >= self.input.header_count {
            return Err(Failure);
        }
        let mut output = core::mem::MaybeUninit::<Header>::uninit();
        // SAFETY: invoke's caller supplies a live header context and callback.
        if unsafe { (self.input.header_at)(self.input.headers, index, output.as_mut_ptr()) } != 0 {
            return Err(Failure);
        }
        // SAFETY: successful host callback initializes both borrowed views.
        let header = unsafe { output.assume_init() };
        // SAFETY: the host promises these views for the input's call lifetime.
        Ok(unsafe { (header.name.as_slice(), header.value.as_slice()) })
    }
}

/// Versioned native function table. No owned Rust value crosses this boundary.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct Api {
    /// Version and exact full C table size.
    pub header: HeaderVersion,
    /// Expected `size_of::<Input>()`.
    pub input_size: u32,
    /// Expected `size_of::<Output>()`.
    pub output_size: u32,
    /// Expected `size_of::<EditSink>()`.
    pub sink_size: u32,
    /// Supported subset of [`CAPABILITIES`].
    pub capabilities: u64,
    /// Synchronous entrypoint; zero means a scalar decision was written.
    pub evaluate: Option<unsafe extern "C" fn(*const Input, *const EditSink, *mut Output) -> i32>,
}

/// Adapt one Rust implementation, containing its panic when `std` is enabled.
/// Returns nonzero on failure and leaves an invalid decision on that path.
///
/// # Safety
/// All pointers must be aligned and valid for this call; input views and the
/// sink must fulfill their documented borrowed contracts. Output is writable.
/// The host must not mutate input concurrently. With `std`, compile with
/// `panic=unwind`. Without it, the module supplies its own panic handler and
/// fulfills the independently approved non-panicking call contract.
pub unsafe fn invoke<M>(module: &M, input: *const Input, sink: *const EditSink, output: *mut Output) -> i32
where
    for<'a> M: RemediationModule<Request<'a>>,
{
    if input.is_null() {
        return 1;
    }
    // SAFETY: this adapter's caller supplies the live canonical HTTP input.
    let request = Request { input: unsafe { &*input } };
    // SAFETY: this adapter forwards the same live sink/output contract to the
    // shared, protocol-independent invocation and Rust panic boundary.
    unsafe { super::module::invoke(module, &request, sink, output) }
}
