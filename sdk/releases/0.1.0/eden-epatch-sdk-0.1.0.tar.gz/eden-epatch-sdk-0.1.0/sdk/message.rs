//! Borrowed incremental message access shared by native protocol adapters.
//!
//! Views and decoder output exist only during a synchronous invocation. The
//! host retains the wire allocation, bounded request state, scratch storage and
//! helper budgets. These C layouts contain no Rust allocator-owned values.

/// Offset-only validation shared by message facades and protocol hosts.
#[path = "message/validation.rs"]
pub mod validation;

use crate::module::{BorrowedBytes, Failure};
use core::cell::RefCell;
use core::ffi::c_void;

/// A helper produced its requested result.
pub const READY: u32 = 0;
/// More original message bytes are required to decide the lookup.
pub const NEED_MORE: u32 = 1;
/// A complete qualified structure contains no matching member.
pub const ABSENT: u32 = 2;
/// The host has not admitted this helper capability.
pub const UNAVAILABLE: u32 = 3;
/// The helper rejected malformed input or an invalid range.
pub const INVALID: u32 = 4;
/// The helper exhausted its admitted size or work budget.
pub const LIMIT: u32 = 5;
/// Qualified bounded zlib decoding capability.
pub const DECODE_ZLIB: u64 = 1;
/// Qualified complete JSON-object root-member span lookup capability.
pub const JSON_ROOT_MEMBER: u64 = 2;
/// Maximum host-owned state bytes exposed to one request's module.
pub const MAX_STATE_BYTES: usize = 256;

/// Half-open byte offsets in the original protocol message, never a pointer.
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ByteRange {
    /// Inclusive byte offset.
    pub start: u32,
    /// Exclusive byte offset, which may refer to bytes not yet received.
    pub end: u32,
}

/// Completeness and capability are explicit independently of an empty value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Availability<T> {
    /// The qualified result is available, including a genuinely empty value.
    Ready(T),
    /// Later admissible input may change the result.
    NeedMore,
    /// This host does not offer the requested optional capability.
    Unavailable,
}

/// Host-owned exclusive request bytes, borrowed only during an invocation.
#[repr(C)]
pub struct MutableBytes {
    /// Writable non-null address, including when length is zero.
    pub data: *mut u8,
    /// Writable byte count, bounded by [`MAX_STATE_BYTES`].
    pub len: usize,
}

/// Decoder result retained by the host until the current view callback returns.
#[repr(C)]
pub struct DecodeOutput {
    /// Exactly the produced bytes, excluding unused output capacity.
    pub bytes: BorrowedBytes,
    /// Number of original encoded bytes consumed.
    pub consumed: u32,
    /// One only after the encoded stream's end has been validated.
    pub complete: u32,
}

/// Common C access table embedded by each incremental protocol input.
#[repr(C)]
pub struct MessageInput {
    /// Arrived original bytes for exactly this message, excluding unread tails.
    pub prefix: BorrowedBytes,
    /// Maximum valid range end: admitted ceiling or known exact frame extent.
    pub extent: u32,
    /// One only when all original message bytes have arrived.
    pub complete: u32,
    /// Host-offered helper bits, independent of module decision permissions.
    pub capabilities: u64,
    /// Exclusive zero-initialized state retained for this request only.
    pub state: MutableBytes,
    /// Current synchronous host context; must never escape this invocation.
    pub context: *mut c_void,
    /// Complete JSON root lookup; writes an original-message value range.
    pub json_root_member: Option<unsafe extern "C" fn(*mut c_void, ByteRange, BorrowedBytes, *mut ByteRange) -> u32>,
    /// Capped zlib decode; writes actual produced size and stream completeness.
    pub decode_zlib: Option<unsafe extern "C" fn(*mut c_void, ByteRange, u32, *mut DecodeOutput) -> u32>,
}

/// A decoder view that cannot outlive its enclosing callback.
pub struct Decoded<'a> {
    /// Actual output bytes rather than an untrusted advertised output length.
    pub bytes: &'a [u8],
    /// Number of consumed original encoded bytes.
    pub consumed: u32,
    /// Whether the decoder validated the stream end.
    pub complete: bool,
}

/// Safe module-side facade over one host-owned incremental message.
///
/// State and scratch borrows cannot escape their callbacks or overlap a second
/// mutable access. No buffer, string or reference-counted owner is cloned.
pub struct Message<'a> {
    /// Host data and callbacks borrowed for this invocation only.
    input: &'a MessageInput,
    /// Exclusive state borrow with reentrant access refused.
    state: RefCell<&'a mut [u8]>,
    /// Prevent another decode from invalidating a still-live scratch view.
    decoding: RefCell<()>,
}

impl<'a> Message<'a> {
    /// Adapt the trusted protocol wrapper's exclusive live input.
    ///
    /// # Safety
    /// The input and every callback/view must obey [`MessageInput`]'s borrowed
    /// contracts; state must be exclusively writable for `'a`. Helpers must not
    /// mutate prefix bytes or invalidate scratch until their view returns.
    pub(crate) unsafe fn new(input: &'a MessageInput) -> Self {
        // SAFETY: the protocol invocation retains exclusive host state.
        let state = unsafe { core::slice::from_raw_parts_mut(input.state.data, input.state.len) };
        Self {
            input,
            state: RefCell::new(state),
            decoding: RefCell::new(()),
        }
    }

    /// Borrow only the bytes that have actually arrived for this message.
    pub fn prefix(&self) -> &'a [u8] {
        // SAFETY: the invocation retains this immutable host allocation.
        unsafe { self.input.prefix.as_slice() }
    }

    /// Whether the original complete message is available.
    pub fn is_complete(&self) -> bool {
        self.input.complete == 1
    }

    /// Read an original range without interpreting absent bytes as empty.
    /// Invalid order fails; a valid range extending past the prefix needs input.
    pub fn bytes(&self, range: ByteRange) -> Result<Availability<&'a [u8]>, Failure> {
        let window = validation::arrival_window(range, self.input.extent, self.input.prefix.len)?;
        let Some(window) = window.filter(|window| window.complete) else {
            return if self.is_complete() {
                Err(Failure)
            } else {
                Ok(Availability::NeedMore)
            };
        };
        let bytes = self.prefix().get(window.start..window.end).ok_or(Failure)?;
        Ok(Availability::Ready(bytes))
    }

    /// Borrow this request's bounded state exclusively for the callback.
    /// The callback's result cannot retain a reference into state.
    /// ```compile_fail
    /// use eden_gateway_remediation::message::Message;
    /// fn escape<'a>(message: &'a Message<'a>) -> &'a mut [u8] {
    ///     message.with_state(|state| state).expect("state")
    /// }
    /// ```
    pub fn with_state<T>(&self, inspect: impl FnOnce(&mut [u8]) -> T) -> Result<T, Failure> {
        let mut state = self.state.try_borrow_mut().map_err(|_| Failure)?;
        Ok(inspect(&mut state))
    }

    /// Locate a decoded root-member name in one complete original JSON object.
    /// Partial input returns NeedMore; absence is conclusive only after parsing.
    /// Duplicate selected names, malformed JSON and host limits fail explicitly.
    pub fn json_root_member(&self, range: ByteRange, name: &str) -> Result<Availability<Option<ByteRange>>, Failure> {
        if self.input.capabilities & JSON_ROOT_MEMBER == 0 {
            return Ok(Availability::Unavailable);
        }
        let Some(lookup) = self.input.json_root_member else {
            return Ok(Availability::Unavailable);
        };
        let mut output = core::mem::MaybeUninit::uninit();
        // SAFETY: the host callback borrows name and writes a scalar range only.
        match unsafe { lookup(self.input.context, range, BorrowedBytes::new(name.as_bytes()), output.as_mut_ptr()) } {
            READY => {
                // SAFETY: READY initializes the scalar output.
                Ok(Availability::Ready(Some(unsafe { output.assume_init() })))
            }
            ABSENT => Ok(Availability::Ready(None)),
            NEED_MORE => Ok(Availability::NeedMore),
            UNAVAILABLE => Ok(Availability::Unavailable),
            _ => Err(Failure),
        }
    }

    /// Inspect capped decoded output without retaining or copying host scratch.
    /// Capacity is a caller request, never authority to exceed the host budget.
    /// The callback sees actual written bytes and explicit stream completeness.
    /// ```compile_fail
    /// use eden_gateway_remediation::message::{ByteRange, Message};
    /// fn escape(message: &Message<'_>) {
    ///     let _ = message.with_zlib(ByteRange { start: 0, end: 1 }, 16, |decoded| decoded.bytes);
    /// }
    /// ```
    pub fn with_zlib<T>(
        &self,
        range: ByteRange,
        output_capacity: u32,
        inspect: impl for<'decoded> FnOnce(Decoded<'decoded>) -> T,
    ) -> Result<Availability<T>, Failure> {
        if self.input.capabilities & DECODE_ZLIB == 0 {
            return Ok(Availability::Unavailable);
        }
        let Some(decode) = self.input.decode_zlib else {
            return Ok(Availability::Unavailable);
        };
        let _guard = self.decoding.try_borrow_mut().map_err(|_| Failure)?;
        let mut output = core::mem::MaybeUninit::<DecodeOutput>::uninit();
        // SAFETY: the host owns scratch throughout this guarded view callback.
        match unsafe { decode(self.input.context, range, output_capacity, output.as_mut_ptr()) } {
            READY => {
                // SAFETY: READY initializes the result and its borrowed bytes.
                let output = unsafe { output.assume_init() };
                if output.bytes.len > output_capacity as usize || output.complete > 1 {
                    return Err(Failure);
                }
                // SAFETY: scratch remains live and cannot be reused under _guard.
                let bytes = unsafe { output.bytes.as_slice() };
                Ok(Availability::Ready(inspect(Decoded {
                    bytes,
                    consumed: output.consumed,
                    complete: output.complete == 1,
                })))
            }
            NEED_MORE => Ok(Availability::NeedMore),
            UNAVAILABLE => Ok(Availability::Unavailable),
            _ => Err(Failure),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Build one test invocation over caller-retained, exclusively owned state.
    fn input(bytes: &[u8], state: &mut [u8]) -> MessageInput {
        MessageInput {
            prefix: BorrowedBytes::new(bytes),
            extent: 8,
            complete: 0,
            capabilities: 0,
            state: MutableBytes { data: state.as_mut_ptr(), len: state.len() },
            context: core::ptr::null_mut(),
            json_root_member: None,
            decode_zlib: None,
        }
    }

    /// Missing bytes and missing capabilities never masquerade as empty values.
    #[test]
    fn partial_ranges_preserve_completeness_and_original_storage() {
        let bytes = b"abc";
        let mut state = [0; 2];
        let input = input(bytes, &mut state);
        // SAFETY: this test keeps wire/state exclusive and alive for the call.
        let message = unsafe { Message::new(&input) };
        assert_eq!(message.prefix().as_ptr(), bytes.as_ptr());
        assert_eq!(message.bytes(ByteRange { start: 0, end: 3 }), Ok(Availability::Ready(&b"abc"[..])));
        assert_eq!(message.bytes(ByteRange { start: 3, end: 4 }), Ok(Availability::NeedMore));
        assert_eq!(message.bytes(ByteRange { start: 0, end: 9 }), Err(Failure));
        assert_eq!(message.bytes(ByteRange { start: 2, end: 1 }), Err(Failure));
        assert_eq!(message.json_root_member(ByteRange { start: 0, end: 3 }, "key"), Ok(Availability::Unavailable));
        assert_eq!(message.with_zlib(ByteRange { start: 0, end: 3 }, 8, |_| ()), Ok(Availability::Unavailable));
    }

    /// Mutable state is request-local and cannot be reborrowed reentrantly.
    #[test]
    fn request_state_is_exclusive_and_updated_in_place() {
        let mut state = [0; 2];
        let input = input(b"", &mut state);
        // SAFETY: the test owns all input state and performs no external access.
        let message = unsafe { Message::new(&input) };
        message
            .with_state(|state| {
                state[0] = 7;
                assert_eq!(message.with_state(|_| ()), Err(Failure));
            })
            .expect("exclusive state");
        assert_eq!(message.with_state(|state| state[0]), Ok(7));
        drop(message);
        assert_eq!(state, [7, 0]);
    }
}
