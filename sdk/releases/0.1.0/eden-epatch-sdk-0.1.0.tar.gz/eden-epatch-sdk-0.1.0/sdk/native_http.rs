//! Versioned C boundary for synchronous, borrowed, trusted native HTTP modules.
//!
//! Modules implement [`HttpRemediation`] in Rust and export an [`Api`] through
//! `eden_http_remediation_v1`. Rust trait objects, allocators and owned values
//! never cross the library boundary. All input pointers expire when `evaluate`
//! returns. Implementations must not retain pointers, unwind, spawn threads or
//! block. This is host-process execution authority, not a tenant sandbox.

/// First stable layout of this explicitly HTTP-only native boundary.
pub const VERSION: u32 = 1;

pub use super::module::{ApiHeader as HeaderVersion, BorrowedBytes as Bytes};

/// One complete duplicate-preserving HTTP header, borrowed from the parser.
#[repr(C)]
pub struct Header {
    /// Original header name bytes.
    pub name: Bytes,
    /// Original header value bytes; native modules receive host-level authority.
    pub value: Bytes,
}

/// Complete unary HTTP request; all storage belongs to the gateway parser.
#[repr(C)]
pub struct Input {
    /// Validated HTTP method.
    pub method: Bytes,
    /// Validated request target, including query string.
    pub target: Bytes,
    /// Complete bounded body, without serialization or cloning.
    pub body: Bytes,
    /// Opaque host header collection; only pass this to `header_at`.
    pub headers: *const core::ffi::c_void,
    /// Number of headers, including duplicates.
    pub header_count: usize,
    /// Writes borrowed header views; returns nonzero on an invalid index.
    pub header_at: unsafe extern "C" fn(*const core::ffi::c_void, usize, *mut Header) -> i32,
}

pub use super::module::ModuleOutput as Output;

/// Native modules implement this synchronous Rust interface behind their export.
pub trait HttpRemediation {
    /// Evaluate complete borrowed input; never retain it past this call.
    fn evaluate(&self, input: &Input) -> Output;
}

/// Immutable function table; its library remains pinned for the process lifetime.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct Api {
    /// Versioned readable prefix.
    pub header: HeaderVersion,
    /// Expected `size_of::<Input>()`.
    pub input_size: u32,
    /// Expected `size_of::<Output>()`.
    pub output_size: u32,
    /// Non-null callback; zero means a decision was written successfully.
    pub evaluate: Option<unsafe extern "C" fn(*const Input, *mut Output) -> i32>,
}
