//! Common gateway-owned remediation contracts, independent of endpoint engines.
//!
//! ## Overview
//! Protocol adapters inspect canonical parsed requests. Immutable prepared
//! policies use the existing verified analyzer tree, and common SDK decision
//! validation enforces the host-owned grant set before protocol effects.
//!
//! ## Architecture
//! This root-level crate owns shared SDK decisions, authoring traits and native
//! image lifetimes. Optional `native-modules` enables Linux cold-path storage
//! and loading; core selection performs no I/O. The host retains publication,
//! endpoint/revision authority and the effect boundary. Protocol adapters reuse
//! [`RemediationModule`] with borrowed inputs. Host builds also expose the
//! `GatewayRemediationAdapter` inspection and mutation contract.
//!
//! ## Core concepts
//! An inspection declares completeness; a selection is only a proposal; a
//! validated decision proves grant validation without granting upstream authority.
//! Protocol views adapt one shared module trait to a versioned native C table.
//! Bounded edit proposals own no module references and require host grants.
//! [`message`] supplies shared borrowed prefixes, bounded request state and
//! capability results for incremental adapters. [`native_http_v3`] supplies
//! the proof-carrying HTTP V1 C table and its explicit `NeedMore` decision.
//!
//! ## Usage
//! ```
//! # #[cfg(feature = "std")] {
//! use eden_gateway_remediation::{InspectionState, RemediationDecision,
//!     RemediationPermissions, validate_decision};
//! let grants = RemediationPermissions { mutable_json_fields: vec![], reject_statuses: vec![403] };
//! let decision = validate_decision(RemediationDecision::Continue, &grants, InspectionState::Complete)
//!     .expect("complete allowed continuation");
//! assert_eq!(decision.decision(), &RemediationDecision::Continue);
//! # }
//! ```
//!
//! ## Error handling
//! Unknown profiles, incomplete inspection, wrong endpoints and unsupported
//! changes are explicit errors. Mandatory protection must refuse on any error.
//!
//! ## Feature flags
//! `std` is enabled by default and supplies host policy, decisions, capacity and
//! central errors. Artifact authors may disable defaults to use the same
//! allocation-free authoring traits and native C layouts with `core` alone.
//! `native-modules` enables host-approved Linux native shared-library loading;
//! it includes `std`. A host build without native loading should retain `std`.
//! no worker transport is enabled. Native libraries remain pinned until their
//! reclamation obligations can be proven by the lifecycle implementation.

#![cfg_attr(not(feature = "std"), no_std)]

#[cfg(feature = "std")]
pub mod capacity;
#[cfg(feature = "native-modules")]
pub mod certificate;
#[cfg(feature = "std")]
pub mod continuation;
#[cfg(feature = "std")]
mod decision;
#[cfg(feature = "std")]
pub mod evidence;
#[cfg(feature = "std")]
mod host;
#[cfg(feature = "std")]
pub mod inventory;
#[cfg(feature = "std")]
pub use host::*;
pub mod message;
pub mod module;
pub use module::RemediationModule;
pub mod native_http;
pub mod native_http_v2;
pub mod native_http_v3;
#[cfg(feature = "std")]
pub mod package;
#[cfg(feature = "native-modules")]
pub mod trust;

#[cfg(all(feature = "native-modules", target_os = "linux"))]
pub mod native_loader;
#[cfg(feature = "std")]
pub use decision::{InspectionState, JsonFieldMutation, RemediationDecision, RemediationPermissions, RemediationStage};
