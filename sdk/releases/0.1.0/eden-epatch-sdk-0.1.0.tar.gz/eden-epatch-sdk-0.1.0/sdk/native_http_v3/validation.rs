//! Pure incremental HTTP descriptor validation over already-readable scalars.
//!
//! The HTTP host supplies actual layout sizes while the native image remains
//! owned. These checks establish metadata policy, not pointer readability.

use crate::message;
use crate::module::validation::capabilities_cover;

/// Scalar v3 table fields copied while the native image owner remains live.
#[derive(Clone, Copy)]
pub struct V3Descriptor {
    /// Declared input layout size, in bytes.
    pub input_size: u32,
    /// Declared scalar output layout size, in bytes.
    pub output_size: u32,
    /// Declared host edit-sink layout size, in bytes.
    pub sink_size: u32,
    /// Declared shared message layout size, in bytes.
    pub message_size: u32,
    /// Requested host-owned state bytes for each request.
    pub state_bytes: u32,
    /// Decisions understood by the module; this declares no host grant.
    pub capabilities: u64,
    /// Helpers required before the first invocation.
    pub required_inputs: u64,
    /// Whether the table supplies an evaluation callback; not its readability.
    pub evaluate_present: bool,
}

/// Actual C layout sizes computed by the qualified host compiler.
#[derive(Clone, Copy)]
pub struct V3Layouts {
    /// Host input layout size, in bytes.
    pub input_size: usize,
    /// Host output layout size, in bytes.
    pub output_size: usize,
    /// Host edit-sink layout size, in bytes.
    pub sink_size: usize,
    /// Host shared message layout size, in bytes.
    pub message_size: usize,
}

/// Validate v3 metadata without dereferencing a module-owned pointer.
#[inline]
pub fn valid_v3_descriptor(value: V3Descriptor, layouts: V3Layouts) -> bool {
    value.input_size as usize == layouts.input_size
        && value.output_size as usize == layouts.output_size
        && value.sink_size as usize == layouts.sink_size
        && value.message_size as usize == layouts.message_size
        && value.state_bytes as usize <= message::MAX_STATE_BYTES
        && value.capabilities != 0
        && capabilities_cover(value.capabilities, crate::native_http_v3::CAPABILITIES)
        && capabilities_cover(value.required_inputs, message::JSON_ROOT_MEMBER | message::DECODE_ZLIB)
        && value.evaluate_present
}
