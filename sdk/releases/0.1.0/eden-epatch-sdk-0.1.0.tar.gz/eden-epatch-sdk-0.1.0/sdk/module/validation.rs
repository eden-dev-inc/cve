//! Protocol-independent scalar validation for standalone module authors and hosts.
//!
//! These production scalar checks are also the Rust-to-Lean extraction roots.
//! Their inputs describe already-readable host values; accepting a scalar does
//! not establish pointer provenance, foreign-code safety or permission to forward.

use super::{ApiHeader, Decision, MAX_EDITS, MAX_REPLACEMENT_BYTES};

/// Require the exact protocol version and complete host table extent.
#[inline]
pub fn matches_header(header: ApiHeader, version: u32, table_size: usize) -> bool {
    header.version == version && header.table_size as usize == table_size
}

/// Check that every required bit is offered, without granting extra authority.
#[inline]
pub fn capabilities_cover(required: u64, offered: u64) -> bool {
    required & !offered == 0
}

/// Scalar snapshot of the host-owned collector before one proposed edit.
#[derive(Clone, Copy)]
pub struct ProposalBudget {
    /// Exact original payload extent admitted by the protocol host.
    pub body_len: usize,
    /// Number of already accepted, host-owned edits.
    pub count: usize,
    /// Total already copied replacement bytes.
    pub bytes: usize,
    /// Original start/end of the last accepted edit, if any.
    pub previous: Option<(u32, u32)>,
    /// Sticky refusal from any earlier failed submission.
    pub failed: bool,
}

/// Untrusted scalar metadata checked before replacement bytes are copied.
#[derive(Clone, Copy)]
pub struct EditOffer {
    /// Inclusive original offset to replace.
    pub start: u32,
    /// Exclusive original offset to replace.
    pub end: u32,
    /// Number of replacement bytes borrowed for this callback.
    pub bytes: usize,
    /// Whether the pointer is non-null; readability remains an FFI obligation.
    pub non_null: bool,
}

/// Compute the exact replacement total after all pre-copy admission checks.
/// Allocation and copying occur only in the host-owned collector after success.
#[inline]
pub fn proposal_total(budget: ProposalBudget, offer: EditOffer) -> Option<usize> {
    if budget.failed
        || offer.start > offer.end
        || offer.end as usize > budget.body_len
        || budget.count >= MAX_EDITS
        || budget.bytes > MAX_REPLACEMENT_BYTES
        || offer.bytes > MAX_REPLACEMENT_BYTES.saturating_sub(budget.bytes)
        || !offer.non_null
    {
        return None;
    }
    if let Some((start, end)) = budget.previous
        && (offer.start < end || offer.start == start)
    {
        return None;
    }
    budget.bytes.checked_add(offer.bytes)
}

/// Interpret only granted decisions with the corresponding edit cardinality.
/// A failed helper submission cannot become a successful scalar decision.
#[inline]
pub fn validated_decision(decision: u32, capabilities: u64, edit_count: usize, failed: bool) -> Option<Decision> {
    if failed || decision > 3 || capabilities & (1 << decision) == 0 {
        return None;
    }
    match decision {
        0 if edit_count == 0 => Some(Decision::Continue),
        1 if edit_count == 0 => Some(Decision::Refuse),
        2 if edit_count != 0 => Some(Decision::Edit),
        3 if edit_count == 0 => Some(Decision::NeedMore),
        _ => None,
    }
}

/// Retain the first helper failure even if subsequent callbacks also fail.
#[inline]
pub fn first_failure<T: Copy>(previous: Option<T>, error: T) -> Option<T> {
    match previous {
        Some(first) => Some(first),
        None => Some(error),
    }
}

/// Prefer sticky helper failure, then reject any nonzero native return code.
#[inline]
pub fn call_failure<T: Copy>(helper_failure: Option<T>, returned: i32, return_error: T) -> Option<T> {
    match helper_failure {
        Some(error) => Some(error),
        None if returned != 0 => Some(return_error),
        None => None,
    }
}
